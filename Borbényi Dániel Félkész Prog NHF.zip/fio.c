#include <stdlib.h>
#include <stdio.h>
#include "fio.h"
#include "debugmalloc.h"

/// @brief A fileban szereplő adatok beolvasásához és láncolt listás tárolásához szükséges adattípus
typedef struct Adat{
    char letter;
    char *morse;
    struct Adat *prev;

} Adat;

/// @brief Megadja egy string hosszát ('\0' előtti elemek száma)
/// @param s A string pointere
/// @return A string hossza
int len(char *s){
    int i = 0;
    while(s[i] != '\0')
        i++;
    return i;
}

/// @brief Átmásol egy stringet elemről elemre
/// @param original A másolandó string pointere
/// @param new A másolással létrejött string pointere
/// @return Sikeres volt-e a másolás
bool strcopy(char *original, char *new){
    int i = 0;
    while(original[i] != '\0'){
        new[i] = original[i];
        i++;
    };
    new[i] = original[i];

    return true;
}

/// @brief Létrehoz egy láncolt listát a .txt fileból beolvasva
/// @param f A filera mutató pointer
/// @return A láncolt lista vége (a láncolt lista fordított a filehoz képest)
Adat *construct(FILE *f){
    Adat *prev = NULL;
    char buffermorse[50];
    char bufferletter;
    while(fscanf(f, "%c", &bufferletter) == 1){ //EOF-nál nem olvas tovább
        Adat *uj = (Adat*) malloc(sizeof(Adat));
        uj->letter = bufferletter;
        fscanf(f, "%s\n", buffermorse); 
        uj->morse = (char*) malloc(len(buffermorse)+1); //miert nem lehet az osszes morze kod 6 karatker? :c
        strcopy(buffermorse, uj->morse);
        uj->prev = prev;
        prev = uj;
    }
    return prev;
}

/// @brief Megnyitja és beolvassa a morseabc.txt filet, amiben az abc található
/// @return A beolvasott adatok listájának pointere
Adat *fin(){
    FILE *f = fopen("morseabc.txt","r");

    if(f == NULL) {
        printf("Nem sikerült a filet megnyitni.\n");
        return NULL;
    }
    else{
        printf("File megnyitva.\n");
        Adat *T = construct(f);
        fclose(f);
        return T;
    }
}

/// @brief Felszabadítja a dinamikusan lefoglalt beolvasáshoz szükséges láncolt listát
/// @param t A láncolt lista pointere
/// @return Sikieres volt-e a felszabadítás
bool felszabadit(Adat *t){
    while(t != NULL){
        Adat *p = t;
        t = t->prev;
        printf("Felszabaditas: %c %s %d\n", p->letter, p->morse, len(p->morse));
        free(p->morse);
        printf("Morze felszabaditva.\n");
        free(p);
        printf("Elem felszabaditva.\n");
    }
    free(t);
    return true;
}

/// @brief Megvizsgálha egy morze kódról hogy csak '.'-ból és '-'-ből áll
/// @param s A vizsgálandó morze kód pointere
/// @return Helyes-e a vizsgált morze kód
bool checkMorse(char *s){
    int i = 0;
    while(s[i] != '\0'){
        if(s[i] != '.' && s[i] != '-')
            return false;
        i++;
    }
    return true;
}