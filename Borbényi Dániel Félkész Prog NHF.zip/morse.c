#include "fio.c"
#include "encode.c"

int main(int argc, char **argv){
    
    Adat *T = fin();
    printf("File sikeresen beolvasva.\n");
    Adat *p = T;
    /*printf("%s modban indult el a program.\n", argv[1]);
    
    while(T != NULL){
        printf("%c: %s\n", T->letter, T->morse),
        T = T->prev;
    }
    printf("argc = %d és argv[1] = %s\n", argc, argv[1]);
    
    if(argc == 1) {
        printf("Hiba: A program nem kapott szükséges parancssori kapcsolót!\n");
        felszabadit(p);
        return 0;
    }*/
    char** EA;
    switch ('e'){
    case 'e':

        EA=buildEncodeArray(p);
        doEncode(EA);
        break;
    case 'd':
        printf("Dekódoló fa work in progress.\n");
        break;
    default:
        printf("Hiba: A program nem kapott szükséges parancssori kapcsolót!\n");
        break;
    }
    felszabadit(p);

    return 0;
}