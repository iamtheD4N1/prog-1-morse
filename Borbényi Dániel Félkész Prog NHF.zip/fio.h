#ifndef FIO_H
#define FIO_H
#include <stdbool.h>

typedef struct Adat Adat;

int len();
bool strcopy();
Adat *construct();
Adat *fin();
bool felszabadit();
bool checkMorse();

#endif